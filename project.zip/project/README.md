# SimpleTesseractExample
A simple android application to demonstrate how to use Tesseract to perform OCR. 

Simply download the project, open in Android Studio, and run on an emulator or device to see results.
